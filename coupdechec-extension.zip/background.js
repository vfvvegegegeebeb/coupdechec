'use strict';

// ── Stockfish bridge ────────────────────────────────────────────────────────
//
// Stockfish pure JS (nmrugg/stockfish.js) fonctionne comme un worker :
//   - reçoit des commandes via  self.onmessage
//   - envoie sa sortie via      self.postMessage
//
// Comme ce service worker EST lui-même un worker, importScripts fonctionne
// directement. On intercepte self.postMessage AVANT le chargement pour
// capturer la sortie UCI, puis on sauvegarde le handler onmessage de
// Stockfish pour lui envoyer des commandes.

let _sfSend    = null;   // handler onmessage de Stockfish (pour envoyer des cmds UCI)
let _state     = 'init'; // 'init' | 'ready'
let _queue     = null;   // requête ANALYZE en attente pendant l'init
let _pending   = null;   // requête en cours { resolve, timeout }
let _lastScore = null;   // score UCI de la dernière ligne info (cp ou mate)

// ── Étape 1 : intercepter la sortie de Stockfish ────────────────────────────
self.postMessage = function (data) {
  if (typeof data !== 'string') return;

  if (data === 'readyok') {
    _state = 'ready';
    if (_queue) { _runAnalysis(_queue); _queue = null; }
    return;
  }

  // Capture le score depuis les lignes info (dernier score avant bestmove)
  if (data.startsWith('info')) {
    const m = data.match(/score (cp|mate) (-?\d+)/);
    if (m) {
      if (m[1] === 'cp') {
        const cp = parseInt(m[2]);
        _lastScore = (cp >= 0 ? '+' : '') + (cp / 100).toFixed(1);
      } else {
        const n = parseInt(m[2]);
        _lastScore = '#' + (n > 0 ? n : n); // mate in N (négatif = mat adverse)
      }
    }
    return;
  }

  if (data.startsWith('bestmove')) {
    const move  = data.split(' ')[1];
    const score = _lastScore;
    _lastScore  = null;
    if (_pending) {
      clearTimeout(_pending.timeout);
      const resolve = _pending.resolve;
      _pending = null;
      resolve(move && move !== '(none)' ? { move, score } : null);
    }
  }
};

// ── Étape 2 : charger Stockfish pure JS ─────────────────────────────────────
try {
  importScripts('stockfish.js');
} catch (_) {
  // stockfish.js absent → les analyses renverront null
}

// ── Étape 3 : capturer le handler de Stockfish, puis vider self.onmessage ───
_sfSend = self.onmessage || null;
self.onmessage = null; // évite tout conflit avec les messages Chrome Extension

// ── Étape 4 : initialisation UCI ────────────────────────────────────────────
function _uci(cmd) {
  if (_sfSend) _sfSend.call(self, { data: cmd });
}

_uci('uci');
_uci('isready');

// Niveau de jeu courant (1–20, 20 = Stockfish max, ~5 = débutant)
let _skillLevel = 20;
chrome.storage.local.get(['skill'], (d) => {
  if (d.skill != null) _skillLevel = d.skill;
});

// ── Analyse ──────────────────────────────────────────────────────────────────
function _runAnalysis(req) {
  _lastScore = null; // reset avant chaque nouvelle analyse
  _uci('stop');
  _uci('setoption name Skill Level value ' + _skillLevel);
  _uci('position fen ' + req.fen);
  _uci('go movetime ' + req.movetime);
  _pending = {
    resolve: req.resolve,
    timeout: setTimeout(function () {
      if (_pending && _pending.resolve === req.resolve) {
        _pending = null;
        req.resolve(null);
      }
    }, req.movetime + 3000)
  };
}

function _analyze(fen, movetime) {
  return new Promise(function (resolve) {
    // Annule l'analyse précédente si elle est encore en attente
    if (_pending) {
      clearTimeout(_pending.timeout);
      const old = _pending.resolve;
      _pending = null;
      old(null);
    }
    const req = { fen, movetime, resolve };
    if (_state === 'ready') {
      _runAnalysis(req);
    } else {
      _queue = req; // sera exécuté dès que readyok arrive
    }
  });
}

// ── Messages depuis content.js ───────────────────────────────────────────────
chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
  if (msg.type === 'ANALYZE') {
    _analyze(msg.fen, msg.movetime || 1000).then(function (result) {
      sendResponse(result || { move: null, score: null });
    });
    return true; // réponse asynchrone
  }

  if (msg.type === 'SF_STOP') {
    _uci('stop');
    if (_pending) { clearTimeout(_pending.timeout); _pending = null; }
    sendResponse({ ok: true });
  }

  if (msg.type === 'SET_SKILL') {
    _skillLevel = Math.max(1, Math.min(20, msg.level));
    sendResponse({ ok: true });
  }

  if (msg.type === 'PING') {
    sendResponse({ ok: true });
  }
});
